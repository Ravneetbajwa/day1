//
//  IDisplay.swift
//  C0728340_Exam1_MAD3004
//
//  Created by MacStudent on 2018-02-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
protocol IDispaly {
 init()
    
   
    func display()
   
  
    
}
