//
//  main.swift
//  C0728340_Exam1_MAD3004
//
//  Created by MacStudent on 2018-02-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var m1 = Manufacturer(ManufacturerId: 1, ManufacturerName: "Dell")
var m2 = Manufacturer(ManufacturerId: 2, ManufacturerName: "Apple")
var ManufacturerDictionary = [String: Manufacturer]()
ManufacturerDictionary.updateValue(m1, forKey: "Manufacturer1")
ManufacturerDictionary.updateValue(m2, forKey: "Manufacturer2")


var p1 = Product(ProductId: 100, ProductName: "Hard Drive", Price: 120.00, Quantity: 20)
//p1.display(ProductId: 100, ProductName: "Hard Drive", Price: 120.00, Quantity: 20)

var p2 = Product(ProductId: 200, ProductName: "Zip Drive", Price: 90.00, Quantity: 40)
//p2.display(ProductId: 200, ProductName: "Zip Drive", Price: 90.00, Quantity: 40)

var p3 = Product(ProductId: 300, ProductName: "Floppy Disk", Price: 50.00, Quantity: 90)
//p3.display(ProductId: 300, ProductName: "Floppy Disk", Price: 50.00, Quantity: 90)

var p4 = Product(ProductId: 400, ProductName: "Monitor", Price: 300.00, Quantity: 100)
//p4.display(ProductId: 400, ProductName: "Monitor", Price: 300.00, Quantity: 100)

var p5 = Product(ProductId: 500, ProductName: "IPhone 7", Price: 1200.00, Quantity: 150)
//p5.display(ProductId: 500, ProductName: "IPhone 7", Price: 1200.00, Quantity: 150)


var ProductDictionary = [String: Product]()

ProductDictionary.updateValue(p1, forKey:"Product1")
ProductDictionary.updateValue(p2, forKey: "Product2")
ProductDictionary.updateValue(p3, forKey: "Product3")
ProductDictionary.updateValue(p4, forKey: "Product4")
ProductDictionary.updateValue(p4, forKey: "Product5")

var o1 = Order()
//o1.display(OrderId: 100, OrderDate:Date(), ProductId: 100)

