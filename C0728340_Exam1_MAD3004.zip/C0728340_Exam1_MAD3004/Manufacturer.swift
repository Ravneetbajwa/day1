//
//  Manufacturer.swift
//  C0728340_Exam1_MAD3004
//
//  Created by MacStudent on 2018-02-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Manufacturer{
    var ManufacturerId: Int?
    var ManufacturerName: String?
    
    required init(ManufacturerId: Int, ManufacturerName: String){
        
        print("Manufacturer Constructor")
        self.ManufacturerId = -1
        self.ManufacturerName = "NO NAME"
    }
    
    func display(){
        print("Manufacturer Id:\(ManufacturerId!)\nManufacturer Name:\(ManufacturerName!)")
    }
}
