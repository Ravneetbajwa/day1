//
//  Order.swift
//  C0728340_Exam1_MAD3004
//
//  Created by MacStudent on 2018-02-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Order: Product{
    var OrderId: Int?
    var OrderDate: Date?
    var ProductArray: Int?
   
    var OrderTotal: Double?
    required init() {
        super.init(ManufacturerId: 1, ManufacturerName: "String")
        print("Order Constructor")
        self.OrderId = -1
       // self.OrderDate = Date
        self.ProductArray = 0
       // self.OrderTotal = 0
    }
    
    required init(ManufacturerId: Int, ManufacturerName: String) {
        fatalError("init(ManufacturerId:ManufacturerName:) has not been implemented")
    }
    
    required init(ProductId: Int, ProductName: String, Price: Double, Quantity: Int) {
        fatalError("init(ProductId:ProductName:Price:Quantity:) has not been implemented")
    }
    
    
    func getOrderById(OrderId:Int) {
        
        if(OrderId == OrderId)
        {
            print("OrderFound")
        }
        else
        {
            print("order not fount")
        }
    }
    func display(OrderId: Int, OrderDate:Date, ProductId:Int, OrderTotal:Double) {
       print(OrderId, OrderDate, ProductId)
    }
    

}
