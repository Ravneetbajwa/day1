//
//  Product.swift
//  C0728340_Exam1_MAD3004
//
//  Created by MacStudent on 2018-02-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Product: Manufacturer{
    var ProductId: Int?
    var ProductName: String?
    var Price: Double?
    var Quantity: Int?
   
    required init(ProductId: Int, ProductName: String, Price: Double, Quantity: Int) {
        super.init(ManufacturerId: 1, ManufacturerName: "String")
     print("Product Constructor")
        self.ProductId = -1
        self.ProductName = "NoName"
        self.Price = 0
        self.Quantity = 0
    }
    
    func showProducts(ProductId: Int, ProductName: String, Price: Double, Quantity: Int)
    {
        self.ProductId = ProductId
        self.ProductName = ProductName
        self.Price =  Price
        self.Quantity = Quantity
    }
    required init(ManufacturerId: Int, ManufacturerName: String) {
        fatalError("init(ManufacturerId:ManufacturerName:) has not been implemented")
    }
    
     func display(ProductId: Int, ProductName: String, Price: Double, Quantity: Int) {
        print("Product Id:\(ProductId)\nProduct Name: \(ProductName) \nPrice: \(Price)\nQuantity: \(Quantity)")
        print("***************")
    }
    
}
